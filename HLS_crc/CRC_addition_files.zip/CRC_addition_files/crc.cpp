

#include "header.h"


void crc_addition(dataStream &inData, cnStream &cnData, dataStream &outData){
    #pragma HLS INTERFACE axis port=inData
    #pragma HLS INTERFACE axis port=outData
    #pragma HLS INTERFACE axis port=cnData
    #pragma HLS interface ap_ctrl_none port=return

    datau8b A = cnData.read().range(7,0);  // DCI Length

    datau25b CRC_POLY_24 = 28487959;

    data_axi input;
    data_axi output;

    // Calculating the number of 128-bit bursts
    datau2b num_bursts = ceil((float)A/128);
    datau7b bits_in_last_burst = A % 128;
    if (bits_in_last_burst == 0) bits_in_last_burst = 128;

    datau25b crc_temp = 0x1FFFFFF;

    // Finding the CRC of DCI
    datau128b last_burst_data = 0;
    datau8b total_bits_processed = 0;

    LOOP_2: for (datau2b i = 0; i < num_bursts; i++) {
#pragma HLS LOOP_TRIPCOUNT min=1 max=2
        input = inData.read();
        datau128b temp = input.data;
        last_burst_data = temp;
        output.data = temp;

        LOOP_2_1: for (int j = 127; j >= 0; j--) {
#pragma HLS UNROLL factor=4
            if (total_bits_processed < A) {
                crc_temp *= 2;
                crc_temp[0] = temp[j];
                if(crc_temp[24] == 1) {
                    crc_temp = crc_temp ^ CRC_POLY_24;
                }
                total_bits_processed++;
            }
        }

        if (i < num_bursts - 1) {
            output.last = 0;
            outData.write(output);
        }
    }

    // Finding the CRC of 24 0's
    LOOP_3: for (datau5b i = 0; i < 24; i++) {
#pragma HLS UNROLL factor=4
        crc_temp *= 2;
        crc_temp[0] = 0;
        if(crc_temp[24] == 1) {
            crc_temp = crc_temp ^ CRC_POLY_24;
        }
    }

    datau24b final_crc = crc_temp.range(23, 0); // get CRC

    datau7b available_bits = 128 - bits_in_last_burst;

    // Writing the last set of output
    if (available_bits >= 24) {
    	datau7b shift_amount = available_bits - 24;
        output.data = last_burst_data ^ ((datau128b)final_crc << shift_amount);
        output.last = 1;
        outData.write(output);
    }
    else {
    	datau7b bits_for_next = 24 - available_bits;
        output.data = last_burst_data ^ ((datau128b)final_crc >> bits_for_next);
        output.last = 0;
        outData.write(output);

        output.data = 0;
        output.data.range(127, 128 - bits_for_next) = final_crc.range(bits_for_next - 1, 0);
        output.last = 1;
        outData.write(output);
    }
}

#include "header.h"

int main()
{

	//Initializing input and output stream variables that are passed to function
	dataStream inDataFIFO;
	cnStream cnDataFIFO;
	dataStream outDataFIFO;

	//Initializing input and output variables
	datau64b cndata;
	data_axi indata;
	data_axi outdata;

	// Array of control/configuration parameters
	int parameters[10][5] =
	{
			{23,128,108,17,120},
			{70,256,216,0,0},
			{12,512,432,10698,62289},
			{24,128,108,14343,14343},
			{71,256,216,23456,62351},
			{128,256,216,43748,55858},
			{120,512,864,1007,0},
			{115,512,1728,2500,4111},
			{140,512,1728,65535,65519},
			{135,512,864,25258,34576}
	};

	for(int test=1;test<=10;test++){

		// Writing the configuration information into stream interface
		datau8b A = parameters[test-1][0];
		cndata.range(7,0)=A;
		cnDataFIFO.write(cndata);

		datau8b K = A+24;
		int burst=  ceil((float)A/128); // calculating the number of bursts
		int count;

		// Reading the data from input test vector file and writing to the input stream interface
		string inFileName = "test_case_"+to_string(test)+"_in"; // converting teh value of test to string
		ifstream input_file_data(inFileName);
		datau128b dataTemp;

		count = burst;
		while (count>0)
		{
			char buffer[32];
			input_file_data.read(buffer, 32); //reading from the file
			string s = "0x";
			for (int j = 0; j < 32 ; j++)
			{
				s += buffer[j];
			}
			istringstream iss(s);
			iss >> hex >> dataTemp;
			indata.data = dataTemp.read();
			if(burst==0){
				indata.last=1;
			}
			else{
				indata.last=0;
			}
			inDataFIFO.write(indata);
			char trailing[1];
			input_file_data.read(trailing,1);
			count--;
		}
		input_file_data.close();  // Closing the file


		// Calling the function
		crc_addition(inDataFIFO, cnDataFIFO, outDataFIFO);

		// Writing the data from the output stream interface into created output_data file
		ofstream output_file("output_data");  //Creates an output file stream and opens/creates the file
		datau128b outTemp;
		count =  ceil((float)K/128);
		while(count>0){
			outDataFIFO>>outdata;
			outTemp=outdata.data.read();
			string s = "";

			for(int j=3;j>=0;j--){
				datau32b readTemp;
				stringstream ss;
				readTemp = outTemp.range(32*j+31,32*j);
				unsigned int u = readTemp.read();
				ss<< std::setfill ('0') << std::setw(8) << uppercase << hex << u;
				s += ss.str();
			}
			output_file<<s;
			output_file<<endl;
			count--;
		}
		output_file.close(); // Closing the file

		// Comparing the output test vector file and created output_data file
		string cmd = "diff -w output_data test_case_"+to_string(test)+"_out_crc";
		if (system(cmd.c_str())){
			printf("Test failed !!!\nOutput data does not match");
			return 1;
		}else {
			cout<<"Test "<<test<<" passed !\n";
		}
	}
	return 0;
}
